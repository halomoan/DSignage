import React, { Component } from "react";
import MRCard from "./MRCard";
import PropTypes from "prop-types";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

export default class Cards extends Component {
  constructor(props) {
    super();
    this.state = {
      rooms: [
        {
          id: "1",
          name: "Regency Room",
          isVacant: false,
          date: "Monday April 20, 2020",
          owner: "Halomoan Kasim",
          time: "03:00 PM - 04:00 PM",
          title:
            "Very Important Meeting With Vendor.Super Super Long of Description ",
          next_isVacant: false,
          next_owner: "Halomoan Kasim",
          next_time: "03:00 PM - 04:00 PM",
          next_title: "Very Important Meeting With Vendor",
        },
        {
          id: "2",
          name: "IT Meeting Room",
          isVacant: true,
          date: "Monday April 20, 2020",
          owner: "Halomoan Kasim",
          time: "03:00 PM - 04:00 PM",
          title:
            "Very Important Meeting With Vendor with very long description ",
          next_isVacant: false,
          next_owner: "Halomoan Kasim",
          next_time: "03:00 PM - 04:00 PM",
          next_title: "Very Important Meeting With Vendor",
        },
      ],
    };
  }

  render() {
    const room0 = this.state.rooms[0];
    const room1 = this.state.rooms[1];
    return (
      <Row>
        <Col>
          <MRCard room={room0} />
        </Col>

        <Col>
          <MRCard room={room1} />
        </Col>
      </Row>
    );
  }
}

//PropTypes
MRCard.propTypes = {
  room: PropTypes.object.isRequired,
};
