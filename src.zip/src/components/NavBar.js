import React from "react";
import styled from "styled-components";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import Logo from "../assets/images/uol-logo.png";

const Styles = styled.div`
  .title {
    color: #fff;
    margin-left: 10px;
    font-family: Arial, Helvetica, sans-serif;

    font-size: 45px;
    font-weight: bold;
    letter-spacing: 3px;
    text-shadow: 3px 3px rgba(103, 128, 159, 0.5);
  }
  .logo {
    margin-bottom: 12px;
  }
  .navbar-brand {
    padding: 0px;
  }
`;

function NavBar() {
  return (
    <Styles>
      <Navbar bg="dark" variant="light" expand="lg">
        <Navbar.Brand href="#">
          <img className="logo" src={Logo} alt="Company Logo" />{" "}
          <span className="title"> MEETING ROOMS </span>
        </Navbar.Brand>
      </Navbar>
    </Styles>
  );
}

export default NavBar;
