import React from "react";
import { Container } from "react-bootstrap";

export const layout = (props) => <Container></Container>;
